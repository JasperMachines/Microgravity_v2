package com.mycompany.Microgravity;

import android.app.*;
import android.content.Intent;
import android.os.*;
import android.media.*;
import android.hardware.*;

public class ToneService extends Service
implements Runnable, SensorEventListener {

    // ===== SENSOR =====
    SensorManager sensorManager;
    Sensor accel;

    float gx, gy, gz;
    final float ALPHA = 0.90f;

    // ===== AUDIO =====
    AudioTrack track;
    Thread audioThread;
    volatile boolean running = true;

    int sampleRate = 44100;

    // Phases
    double px = 0, py = 0, pz = 0;

    // Frequencies
    volatile double fx = 600;
    volatile double fy = 1200;
    volatile double fz = 7400;

    // Soft clip
    double drive = 1.4;

    @Override
    public void onCreate() {
        super.onCreate();

        // ---- SENSOR ----
        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(this, accel, SensorManager.SENSOR_DELAY_GAME);

        // ---- FOREGROUND ----
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
				"poly_gravity",
				"Poly Gravity Synth",
				NotificationManager.IMPORTANCE_LOW);

            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE))
				.createNotificationChannel(ch);

            startForeground(1,
							new Notification.Builder(this, "poly_gravity")
                            .setSmallIcon(android.R.drawable.ic_media_play)
                            .setContentTitle("Poly Gravity Synth")
                            .setContentText("3-voice gravity audio")
                            .build());
        }

        int bufferSize = AudioTrack.getMinBufferSize(
			sampleRate,
			AudioFormat.CHANNEL_OUT_MONO,
			AudioFormat.ENCODING_PCM_16BIT);

        track = new AudioTrack(
			AudioManager.STREAM_MUSIC,
			sampleRate,
			AudioFormat.CHANNEL_OUT_MONO,
			AudioFormat.ENCODING_PCM_16BIT,
			bufferSize,
			AudioTrack.MODE_STREAM);

        track.play();

        audioThread = new Thread(this);
        audioThread.start();
    }

    // ===== AUDIO THREAD =====
    @Override
    public void run() {
        short[] buffer = new short[1024];

        while (running) {
            for (int i = 0; i < buffer.length; i++) {

                double sx = Math.sin(px);
                double sy = Math.sin(py);
                double sz = Math.sin(pz);

                double mix = (sx + sy + sz) / 3.0;

                // SOFT CLIP
                mix = Math.tanh(mix * drive);

                buffer[i] = (short)(mix * 32767);

                px += 2 * Math.PI * fx / sampleRate;
                py += 2 * Math.PI * fy / sampleRate;
                pz += 2 * Math.PI * fz / sampleRate;

                if (px > 2*Math.PI) px -= 2*Math.PI;
                if (py > 2*Math.PI) py -= 2*Math.PI;
                if (pz > 2*Math.PI) pz -= 2*Math.PI;
            }
            track.write(buffer, 0, buffer.length);
        }
    }

    // ===== SENSOR =====
    @Override
    public void onSensorChanged(SensorEvent e) {

        float ax = e.values[0];
        float ay = e.values[1];
        float az = e.values[2];

        gx = ALPHA * gx + (1 - ALPHA) * ax;
        gy = ALPHA * gy + (1 - ALPHA) * ay;
        gz = ALPHA * gz + (1 - ALPHA) * az;

        fx = map(Math.abs(gx), 0, 10, 300, 4000);
        fy = map(Math.abs(gy), 0, 10, 300, 8000);
        fz = map(Math.abs(gz), 0, 10, 300, 13000);
    }

    @Override public void onAccuracyChanged(Sensor s, int a) {}

    @Override
    public void onDestroy() {
        running = false;
        sensorManager.unregisterListener(this);
        track.stop();
        track.release();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }

    double map(double v, double inMin, double inMax, double outMin, double outMax) {
        return outMin + (v - inMin) * (outMax - outMin) / (inMax - inMin);
    }
}
