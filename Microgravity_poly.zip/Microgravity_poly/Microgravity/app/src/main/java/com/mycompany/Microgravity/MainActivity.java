package com.mycompany.Microgravity;

import android.app.Activity;

import android.widget.TextView;
import android.widget.LinearLayout;
import android.content.Intent;
import android.os.Bundle;
import android.widget.*;


public class MainActivity extends Activity  {

    

    TextView text;
	//Button  stopbtn;

 //   TextView levels;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


		
     //  stopbtn =  findViewById(R.id.stopbtn);
		
        // start background audio service
        startService(new Intent(this, ToneService.class));
    }

		
		
		

}
